#include "Heap.h"


template <typename T>
Heap<T>::Heap(bool (*comp)(T,T)){
    comp = comp;
    if(comp(2,1)){
        is_min = false;
    }else{
        is_min = true;
    }
}

template <typename T>
void Heap<T>::swap(int a, int b){
    T& temp = h[a];
    h[a] = h[b];
    h[b] = temp;
}

template <typename T>
void Heap<T>::insert(T a){
    h.push_back(a);
    int index = h.size() - 1;
    while(index != 0 && comp(h[index], h[parentIndex(index)])){
        swap(index, parentIndex(index));
        index = parentIndex(index);

    }

}


template <typename T>
void Heap<T>::remove(T a){
    
}
/*
template <class T>
static bool gt(T a, T b){
	return a > b;
}

template <class T>
static bool lt(T a, T b){
	return a < b;
}

*/