#include "Heap.h"
#include "MM.h"
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
template <class T>
static bool gt(T a, T b){
	return a > b;
}

template <class T>
static bool lt(T a, T b){
	return a < b;
}
*/

int main(int argc, char *argv[])
{
    string heaptype;
    string insertword;
    string removeword;
    ifstream insertfile(argv[2]);
    ifstream removefile(argv[3]);

    if(heaptype == "heap")
    {
        int size = 0;
        // std::vector<int> heap_array;        

        Heap<int> mx(gt);
        Heap<int> mi(lt);
        while(getline(insertfile,insertword))
        {
            size += 1;
            mx.insert(stoi(insertword));
            mi.insert(stoi(insertword));
        }
        insertfile.close();
        while(getline(removefile,removeword))
        {
            size -= 1;
            mx.remove(stoi(removeword));
            mi.remove(stoi(removeword));
        }
        removefile.close();

        cout << "Min Heap:" << endl;
        cout << "Size = " << mi.get_size() << endl;
        cout << "Min = " << mi.get_min() << endl;
        cout << "Max = " << mi.get_max() << endl;
        cout << "Max Heap:" << endl;
        cout << "Size = " << mx.get_size() << endl;
        cout << "Min = " << mx.get_min() << endl;
        cout << "Max = " << mx.get_max() << endl;
    }
    else if(heaptype == "minmedianmax")
    {
        int size = 0;
        std::vector<int> heap_array;
        MM<int> MMHeap(0,0);
        while(getline(insertfile,insertword))
        {
            size += 1;
            MMHeap.insert(stoi(insertword));
        }
        insertfile.close();
        while(getline(removefile,removeword))
        {
            size -= 1;
            MMHeap.remove(stoi(removeword));
        }
        removefile.close();

        cout << "MinMedianMaxSketch:" << endl;
        cout << "Size = " << MMHeap.get_size() << endl;
        cout << "Min = " << MMHeap.get_minimum() << endl;
        cout << "Max = " << MMHeap.get_maximum() << endl;
    }
    return 0;
}