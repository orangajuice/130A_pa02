#ifndef HEAP_H
#define HEAP_H
#include <iostream>
#include <vector>

using namespace std;

template <typename T>
class Heap{
	public:
		Heap(bool (*comp)(T,T));
		void insert(T a);
		void remove(T a);
		T get_root();
		T extract_root();
		T get_min();
		T get_max();
		int get_size(){return h.size();}
		bool search(T a);
		int height();
		int leftIndex(int i){return 2*i + 1;}
		int rightIndex(int i){return 2*i + 2;}
		int parentIndex(int i){return (i-1) / 2;}
		void swap(int a, int b);
		bool gt(T a, T b);
		bool lt(T a, T b);


	private:
		vector<T> h;
		bool (*comp)(T,T);
		bool is_min;
};


	
#endif
